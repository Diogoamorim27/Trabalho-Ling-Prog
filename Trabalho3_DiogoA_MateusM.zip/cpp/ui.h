#include <string>
#include <vector>

using namespace std;

int init();

int callMenu(vector <string>);

int callScrollingMenu(vector <string>);

void showError(string);

string getInput(string prompt);


