#ifndef PLAY_EPISODE_H
#define PLAY_EPISODE_H

#include <iostream>

#include "episode.h"

using namespace std;

void playEpisode(Episode, string);

#endif
