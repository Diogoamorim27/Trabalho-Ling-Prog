#ifndef DOWNLOAD_EPISODE_H
#define DOWNLOAD_EPISODE_H

#include <iostream>
#include <string>

#include "episode.h"

using namespace std;

void downloadEpisode(Episode, string);

#endif
