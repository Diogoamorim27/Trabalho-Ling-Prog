struct Vector2
{
	float x;
	float y;
};
