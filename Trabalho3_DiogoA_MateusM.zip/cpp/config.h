#ifndef CONFIG_H
#define CONFIG_H

#define PLAY_EPISODE_DEFAULT_PROGRAM    "xdg-open"

#endif
