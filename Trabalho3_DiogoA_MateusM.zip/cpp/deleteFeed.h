#ifndef DELETE_FEED_H
#define DELETE_FEED_H

#include <iostream>
#include <string>

#include "feed.h"

using namespace std;

void deleteFeed(Feed, string);

#endif
