use warnings;
use strict;

require "./perl/create_empty_json_array.pl";

create_empty_json_array($ARGV[0]);
